const ext = typeof browser !== "undefined" ? browser : chrome;

const tokenInput = document.getElementById("tokenInput");
const toggleBtn = document.getElementById("toggleBtn");
const saveBtn = document.getElementById("saveBtn");
const clearBtn = document.getElementById("clearBtn");
const statusEl = document.getElementById("status");

function setStatus(msg, cls = "") {
  statusEl.textContent = msg;
  statusEl.className = cls;
}

function loadToken() {
  if (typeof browser !== "undefined" && browser.storage?.local?.get) {
    browser.storage.local.get("skippyWebhookToken").then((res) => {
      const val = (res?.skippyWebhookToken || "").trim();
      tokenInput.value = val;
      if (val) {
        setStatus("✅ Token configured and ready.", "ok");
      } else {
        setStatus("⚠️ No token saved yet.", "warn");
      }
    });
    return;
  }
  chrome.storage.local.get("skippyWebhookToken", (res) => {
    const val = ((res && res.skippyWebhookToken) || "").trim();
    tokenInput.value = val;
    if (val) {
      setStatus("✅ Token configured and ready.", "ok");
    } else {
      setStatus("⚠️ No token saved yet.", "warn");
    }
  });
}

function saveToken(val) {
  const clean = (val || "").trim();
  const payload = { skippyWebhookToken: clean };
  const onDone = () => {
    if (clean) {
      setStatus("✅ Token saved! Ready to capture LinkedIn jobs.", "ok");
    } else {
      setStatus("⚠️ Token cleared.", "warn");
    }
  };
  if (typeof browser !== "undefined" && browser.storage?.local?.set) {
    browser.storage.local.set(payload).then(onDone);
    return;
  }
  chrome.storage.local.set(payload, onDone);
}

toggleBtn.addEventListener("click", () => {
  tokenInput.type = tokenInput.type === "password" ? "text" : "password";
});

saveBtn.addEventListener("click", () => {
  saveToken(tokenInput.value);
});

clearBtn.addEventListener("click", () => {
  tokenInput.value = "";
  saveToken("");
});

tokenInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    saveToken(tokenInput.value);
  }
});

loadToken();
