const ext = typeof browser !== "undefined" ? browser : chrome;
const MENU_ID = "send_to_skippy";

function registerContextMenu() {
  try {
    ext.contextMenus.create(
      {
        id: MENU_ID,
        title: "⚡ Send Listing to Skippy",
        contexts: ["all"]
      },
      () => {
        // Suppress duplicate menu item ID errors across reloads/restarts
        void ext.runtime?.lastError;
      }
    );
  } catch (e) {
    // Ignore synchronous errors if menu already exists
  }
}

ext.runtime.onInstalled.addListener(() => {
  registerContextMenu();
});

if (ext.runtime.onStartup) {
  ext.runtime.onStartup.addListener(() => {
    registerContextMenu();
  });
}

// Ensure context menu is registered when background script wakes up (for Firefox event pages / temporary add-ons)
registerContextMenu();

function sendTabMessage(tabId, message) {
  if (typeof browser !== "undefined" && browser.tabs?.sendMessage) {
    return browser.tabs.sendMessage(tabId, message);
  }
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}

function injectContentScript(tabId) {
  if (typeof browser !== "undefined" && browser.scripting?.executeScript) {
    return browser.scripting.executeScript({
      target: { tabId },
      files: ["content.js"]
    });
  }
  return new Promise((resolve, reject) => {
    chrome.scripting.executeScript(
      {
        target: { tabId },
        files: ["content.js"]
      },
      (results) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(results);
        }
      }
    );
  });
}

async function triggerScrape(tabId) {
  try {
    await sendTabMessage(tabId, { action: "scrape_clicked_job" });
  } catch (err) {
    // If the content script is not loaded yet (e.g. tab was open before extension install/reload),
    // inject it programmatically and retry
    try {
      await injectContentScript(tabId);
      await sendTabMessage(tabId, { action: "scrape_clicked_job" });
    } catch (injectErr) {
      console.error("Skippy: Failed to inject content script:", injectErr);
    }
  }
}

ext.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === MENU_ID && tab?.id) {
    triggerScrape(tab.id);
  }
});

ext.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request && request.action === "sendToSkippy") {
    const endpoints = [
      'http://127.0.0.1:8000/api/ingest',
      'http://localhost:8000/api/ingest'
    ];

    const tryFetch = async () => {
      let lastError = null;
      for (const url of endpoints) {
        try {
          const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(request.payload)
          });
          if (res.ok) {
            return { success: true };
          } else {
            const errorText = await res.text().catch(() => "");
            lastError = `Server returned ${res.status}: ${errorText}`;
          }
        } catch (err) {
          lastError = err.toString();
        }
      }
      return { success: false, error: lastError || "Failed to connect to Skippy backend." };
    };

    if (typeof browser !== "undefined") {
      return tryFetch();
    }

    tryFetch().then(sendResponse);
    return true; // Keep message channel open for async response in Chromium
  }
});
